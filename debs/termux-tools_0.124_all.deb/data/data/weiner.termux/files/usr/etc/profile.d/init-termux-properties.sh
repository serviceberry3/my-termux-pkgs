if [ ! -f /data/data/weiner.termux/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/weiner.termux/files/home/.termux/termux.properties ]; then
mkdir -p /data/data/weiner.termux/files/home/.termux
cp /data/data/weiner.termux/files/usr/share/examples/termux/termux.properties /data/data/weiner.termux/files/home/.termux/
fi
